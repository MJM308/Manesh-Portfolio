const fs = require('fs');
let html = fs.readFileSync('src/app/app.html', 'utf8');

// Fix the mistakes created by the previous regex script replacing 'text-white' over existing combinations
html = html.replace(/dark:text-slate-900 dark:text-white/g, 'dark:text-white');

fs.writeFileSync('src/app/app.html', html, 'utf8');
console.log("Fixed mistakes");
