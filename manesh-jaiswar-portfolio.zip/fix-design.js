const fs = require('fs');

let html = fs.readFileSync('src/app/app.html', 'utf8');

// Replace standard colors with full dark mode equivalents
html = html.replace(/text-white\/70/g, 'text-slate-600 dark:text-white/70');
html = html.replace(/text-white\/60/g, 'text-slate-500 dark:text-white/60');
html = html.replace(/text-white\/50/g, 'text-slate-500 dark:text-white/50');
html = html.replace(/text-white\/40/g, 'text-slate-400 dark:text-white/40');
html = html.replace(/text-white\/30/g, 'text-slate-400 dark:text-white/30');
html = html.replace(/text-white\/90/g, 'text-slate-800 dark:text-white/90');
html = html.replace(/text-white/g, 'text-slate-900 dark:text-white');

html = html.replace(/border-white\/10/g, 'border-slate-200 dark:border-white/10');
html = html.replace(/border-white\/20/g, 'border-slate-300 dark:border-white/20');

html = html.replace(/bg-white\/5/g, 'bg-slate-100 dark:bg-white/5');
html = html.replace(/bg-brand-bg\/50/g, 'bg-slate-100/50 dark:bg-brand-bg/50');
html = html.replace(/text-brand-bg/g, 'text-white dark:text-brand-bg'); 

// Tidy up where text-slate-900 might have replaced text-white in middle of words (unlikely, but just in case)
html = html.replace(/text-slate-900 dark:text-slate-900 dark:text-white/g, 'text-slate-900 dark:text-white');

fs.writeFileSync('src/app/app.html', html, 'utf8');

let css = fs.readFileSync('src/styles.css', 'utf8');

// Update CSS for Light Mode support
css = css.replace(/@apply bg-brand-bg text-white antialiased/, '@apply bg-slate-50 dark:bg-brand-bg text-slate-900 dark:text-white antialiased');
css = css.replace(/#ffffff;/, '#e2e8f0;'); // update light mode bg layer color to slate-200ish
css = css.replace(/html \{[\s\S]*?background-color: #0a051d;\n\}/g, `html {
  scroll-behavior: smooth;
}`);
css = css.replace(/#0a051d;/g, '#0a051d;');

css = css.replace(/.app-bg-layer \{[\s\S]*?\}/, `.app-bg-layer {
  @apply fixed inset-0 z-[-1] pointer-events-none transition-colors duration-500;
  background: radial-gradient(circle at 20% 20%, rgba(59,130,246,0.15) 0%, transparent 40%),
              radial-gradient(circle at 80% 80%, rgba(168,85,247,0.15) 0%, transparent 40%),
              #f8fafc;
}
html.dark .app-bg-layer {
  background: radial-gradient(circle at 20% 20%, rgba(59,130,246,0.15) 0%, transparent 40%),
              radial-gradient(circle at 80% 80%, rgba(168,85,247,0.15) 0%, transparent 40%),
              #0a051d;
}`);

css = css.replace(/background: rgba\(255, 255, 255, 0\.03\);/g, '@apply bg-white/60 dark:bg-white/5;');
css = css.replace(/border: 1px solid rgba\(255, 255, 255, 0\.1\);/g, '@apply border border-slate-200 dark:border-white/10;');

fs.writeFileSync('src/styles.css', css, 'utf8');

console.log("Migration complete");
