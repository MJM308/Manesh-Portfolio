import {ChangeDetectionStrategy, Component, signal, effect, OnInit, OnDestroy, Inject, PLATFORM_ID} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {MatIconModule} from '@angular/material/icon';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit, OnDestroy {
  isDarkMode = signal(false);
  currentYear = signal(new Date().getFullYear());
  showSuccessToast = signal(false);
  
  // Typing Effect State
  titles = ['MCA Graduate', 'Software Developer', 'Full Stack Developer'];
  currentTitleIndex = 0;
  currentTitle = signal('');
  isDeleting = false;
  typingTimeout: any;

  // Data
  education = [
    {
      degree: 'Master of Computer Application (MCA)',
      institution: 'Manipal University Jaipur',
      period: '2023 – 2025',
      score: 'CGPA: 8.43'
    },
    {
      degree: 'Bachelor of Computer Application (BCA)',
      institution: 'Pune University',
      period: '2019 – 2022',
      score: 'Percentage: 78%'
    },
    {
      degree: 'Higher Secondary Certificate (HSC)',
      institution: 'Gujarat Board',
      period: '2017 – 2019',
      score: 'Percentage: 86.65%'
    },
    {
      degree: 'Secondary School Certificate (SSC)',
      institution: 'Gujarat Board',
      period: '2017',
      score: 'Percentage: 80.97%'
    }
  ];

  skillsList = [
    {
      category: 'Programming Languages',
      items: [
        { name: 'Java', level: 85 },
        { name: 'Python', level: 80 },
        { name: 'JavaScript', level: 90 },
        { name: 'SQL', level: 85 }
      ]
    },
    {
      category: 'Frontend',
      items: [
        { name: 'HTML5/CSS3', level: 95 },
        { name: 'JavaScript', level: 90 },
        { name: 'React.js', level: 85 },
        { name: 'Angular', level: 75 },
        { name: 'Bootstrap / Tailwind CSS', level: 88 }
      ]
    },
    {
      category: 'Backend',
      items: [
        { name: 'Node.js', level: 80 },
        { name: 'Express.js', level: 85 },
        { name: 'REST APIs', level: 88 }
      ]
    },
    {
      category: 'Database & Tools',
      items: [
        { name: 'MySQL / MongoDB', level: 82 },
        { name: 'Git & GitHub', level: 90 },
        { name: 'Docker / Postman', level: 75 }
      ]
    }
  ];

  projects = [
    {
      title: 'Student Management System',
      description: 'Developed a robust web application for managing student records. Features include CRUD operations and secure authentication workflows.',
      stack: ['Angular', 'Dot Net', 'Sql'],
      image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=600&auto=format&fit=crop',
      link: '#'
    },
    {
      title: 'E-Commerce Platform',
      description: 'Responsive online shopping platform featuring a comprehensive product catalog, active cart management, and payment integration.',
      stack: ['React', 'Express', 'MongoDB'],
      image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?q=80&w=600&auto=format&fit=crop',
      link: '#'
    },
    {
      title: 'Modern Portfolio',
      description: 'Personal portfolio highlighting projects and skills using a glassmorphism design approach with smooth interactions.',
      stack: ['HTML', 'CSS', 'JavaScript'],
      image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?q=80&w=600&auto=format&fit=crop',
      link: '#'
    }
  ];

  certifications = [
    { name: 'Java Programming', icon: 'code' },
    { name: 'Python Programming', icon: 'terminal' },
    { name: 'Web Development', icon: 'web' },
    { name: 'Database Management', icon: 'storage' },
    { name: 'Cloud Computing', icon: 'cloud' }
  ];

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {
    effect(() => {
      if (isPlatformBrowser(this.platformId)) {
        if (this.isDarkMode()) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }
    });
  }

  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      // Check system preference
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      this.isDarkMode.set(prefersDark);
      this.typeEffect();
    }
  }

  ngOnDestroy() {
    if (this.typingTimeout) {
      clearTimeout(this.typingTimeout);
    }
  }

  toggleTheme() {
    this.isDarkMode.update(v => !v);
  }

  typeEffect() {
    const fullText = this.titles[this.currentTitleIndex];
    let typeSpeed = 100;

    if (this.isDeleting) {
      this.currentTitle.update(t => fullText.substring(0, t.length - 1));
      typeSpeed = 50;
    } else {
      this.currentTitle.update(t => fullText.substring(0, t.length + 1));
    }

    if (!this.isDeleting && this.currentTitle() === fullText) {
      typeSpeed = 2000;
      this.isDeleting = true;
    } else if (this.isDeleting && this.currentTitle() === '') {
      this.isDeleting = false;
      this.currentTitleIndex = (this.currentTitleIndex + 1) % this.titles.length;
      typeSpeed = 500;
    }

    this.typingTimeout = setTimeout(() => this.typeEffect(), typeSpeed);
  }

  onFormSubmit() {
    this.showSuccessToast.set(true);
    setTimeout(() => {
      this.showSuccessToast.set(false);
    }, 4000);
  }
}
